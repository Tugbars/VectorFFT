/* vfft_r25_plan_wisdom.h
 *
 * Auto-generated plan-protocol selection for R=25.
 * Bench host: unknown
 *
 * Each function returns 1 if the planner should use the named protocol
 * for a stage with the given (me, ios), 0 otherwise.
 *
 * Derived from cross-protocol comparison at each sweep point. The
 * planner should consult these AFTER the codelet-level dispatcher
 * has been selected — they drive twiddle-table layout and the
 * K-blocked execution path.
 */
#ifndef VFFT_R25_PLAN_WISDOM_H
#define VFFT_R25_PLAN_WISDOM_H

#include <stddef.h>

/* Cross-protocol comparison (fwd direction, AVX2):
 *   me    ios   winning_protocol   winning_ns
 *       8     8   t1s               278.7
 *       8    16   t1s               279.7
 *       8   200   t1s               275.1
 *       8   256   log3              453.1
 *      16    16   t1s               530.9
 *      16    24   log3              556.0
 *      16   400   t1s               529.2
 *      16   512   t1s              1053.0
 *      32    32   t1s              1027.5
 *      32    40   t1s              1032.4
 *      32   800   t1s              1048.6
 *      32  1024   t1s              2361.7
 *      64    64   t1s              2041.4
 *      64    72   t1s              2159.5
 *      64  1600   t1s              2084.2
 *      64  2048   t1s              4758.0
 *     128   128   t1s              4469.0
 *     128   136   t1s              4329.6
 *     128  3200   t1s              6345.0
 *     128  4096   t1s              9523.3
 *     256   256   t1s             13730.7
 *     256   264   t1s              8461.3
 *     256  6400   t1s             16700.0
 *     256  8192   t1s             18871.0
 */

/* Should the planner use log3 protocol at (me, ios)? */
static inline int radix25_prefer_log3(size_t me, size_t ios) {
    (void)ios;  /* may be unused if rules are me-only */
    return 0;
}

/* Should the planner use t1s protocol at (me, ios)? */
static inline int radix25_prefer_t1s(size_t me, size_t ios) {
    (void)ios;  /* may be unused if rules are me-only */
    /* Bench wins at me ∈ {8, 16, 32, 64, 128, 256} */
    if (me >= 8 && me <= 256) return 1;
    return 0;
}

#endif /* VFFT_R25_PLAN_WISDOM_H */
